-- Ver estructura real de tabla registro_diario
DESC registro_diario;

-- Ver estructura de registro_hojas_ruta
DESC registro_hojas_ruta;

-- Ver estructura de contenedores_fisicos
DESC contenedores_fisicos;
