-- Verificar estructura de tabla prestamos
DESCRIBE prestamos;

-- Alternativa: mostrar todas las columnas
SHOW COLUMNS FROM prestamos;

-- Ver algunos registros de ejemplo
SELECT * FROM prestamos LIMIT 3;
