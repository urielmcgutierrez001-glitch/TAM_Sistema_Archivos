-- Ver estructura de tipo_documento
DESC tipo_documento;

-- Ver valores
SELECT * FROM tipo_documento ORDER BY orden;
