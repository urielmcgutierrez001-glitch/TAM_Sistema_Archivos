<?php
/**
 * Configuración de Base de Datos para Clever Cloud
 * Utiliza variables de entorno proporcionadas automáticamente
 */

// Clever Cloud proporciona estas variables automáticamente:
// MYSQL_ADDON_HOST, MYSQL_ADDON_DB, MYSQL_ADDON_USER, MYSQL_ADDON_PASSWORD

return [
    'host' => getenv('MYSQL_ADDON_HOST') ?: 'localhost',
    'dbname' => getenv('MYSQL_ADDON_DB') ?: 'tamep_archivos',
    'username' => getenv('MYSQL_ADDON_USER') ?: 'root',
    'password' => getenv('MYSQL_ADDON_PASSWORD') ?: '',
    'charset' => 'utf8mb4',
    'port' => getenv('MYSQL_ADDON_PORT') ?: 3306
];
